import React, { useState, useRef } from 'react';
import {
  TouchableOpacity,
  Alert,
  TextInput,
  Button,
  TouchableWithoutFeedback,
  Keyboard,
  TouchableHighlight,
  Modal,
  View,
  Text,
  Image,
  SectionList,
  Switch,
  StyleSheet,
  ScrollView,
  FlatList,
  Animated
} from 'react-native';

const TripGoApp = () => {
  // State management
  const [name, setName] = useState('');
  const [destination, setDestination] = useState('');
  const [date, setDate] = useState('');
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  // Sample route data
  const routes = [
    {
      title: 'Popular Routes',
      data: [
        { id: '1', from: 'Kathmandu', to: 'Pokhara', price: 'NPR 1200', duration: '6-7 hours', image: 'https://i.imgur.com/pJ6JYzq.jpg' },
        { id: '2', from: 'Kathmandu', to: 'Chitwan', price: 'NPR 800', duration: '5 hours', image: 'https://i.imgur.com/7JyQ6Yf.jpg' },
        { id: '3', from: 'Kathmandu', to: 'Lumbini', price: 'NPR 1500', duration: '8 hours', image: 'https://i.imgur.com/9JzQY6p.jpg' },
      ],
    },
  ];

  // Animation for booking confirmation
  const fadeIn = () => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 1000,
      useNativeDriver: true,
    }).start();
  };

  // Handle booking submission
  const handleBooking = () => {
    if (!name || !destination || !date) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }
    fadeIn();
    setModalVisible(true);
  };

  // Render each route item
  const renderRouteItem = ({ item }) => (
    <TouchableOpacity style={styles.routeItem}>
      <Image source={{ uri: item.image }} style={styles.routeImage} />
      <View style={styles.routeInfo}>
        <Text style={styles.routeTitle}>{item.from} to {item.to}</Text>
        <Text style={styles.routeDetail}>Price: {item.price}</Text>
        <Text style={styles.routeDetail}>Duration: {item.duration}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Image 
            source={{ uri: 'https://i.imgur.com/4ZQ6Y7a.png' }} 
            style={styles.logo} 
          />
          <Text style={styles.headerText}>Trip-Go</Text>
        </View>

        {/* Main Content */}
        <ScrollView contentContainerStyle={styles.content}>
          {/* Hero Section */}
          <Animated.View style={[styles.hero, { opacity: fadeAnim }]}>
            <Text style={styles.heroText}>Your Journey Starts Here</Text>
          </Animated.View>

          {/* Booking Form */}
          <View style={styles.card}>
            <Text style={styles.sectionTitle}>Book Your Trip</Text>
            
            <TextInput
              style={styles.input}
              placeholder="Your Name"
              value={name}
              onChangeText={setName}
            />
            
            <TextInput
              style={styles.input}
              placeholder="Destination"
              value={destination}
              onChangeText={setDestination}
            />
            
            <TextInput
              style={styles.input}
              placeholder="Travel Date (DD/MM/YYYY)"
              value={date}
              onChangeText={setDate}
            />
            
            <TouchableHighlight
              style={styles.bookButton}
              underlayColor="#0a67c4"
              onPress={handleBooking}
            >
              <Text style={styles.buttonText}>Confirm Booking</Text>
            </TouchableHighlight>
          </View>

          {/* Routes Section */}
          <View style={styles.card}>
            <SectionList
              sections={routes}
              keyExtractor={(item) => item.id}
              renderItem={renderRouteItem}
              renderSectionHeader={({ section: { title } }) => (
                <Text style={styles.sectionHeader}>{title}</Text>
              )}
              ListHeaderComponent={
                <Text style={styles.sectionTitle}>Available Routes</Text>
              }
            />
          </View>

          {/* Settings */}
          <View style={styles.card}>
            <Text style={styles.sectionTitle}>Settings</Text>
            <View style={styles.switchContainer}>
              <Text>Enable Notifications</Text>
              <Switch
                trackColor={{ false: "#767577", true: "#096af1" }}
                thumbColor={notificationsEnabled ? "#f4f4f4" : "#f4f4f4"}
                onValueChange={() => setNotificationsEnabled(!notificationsEnabled)}
                value={notificationsEnabled}
              />
            </View>
          </View>
        </ScrollView>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>Developed by Safal Subedi</Text>
        </View>

        {/* Booking Confirmation Modal */}
        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => setModalVisible(false)}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Booking Confirmed!</Text>
              <Text style={styles.modalText}>
                {name}, your trip to {destination} on {date} is confirmed.
              </Text>
              <TouchableOpacity
                style={styles.modalButton}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.modalButtonText}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </View>
    </TouchableWithoutFeedback>
  );
};

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#096af1',
    padding: 16,
  },
  logo: {
    width: 40,
    height: 40,
    marginRight: 10,
  },
  headerText: {
    color: 'white',
    fontSize: 22,
    fontWeight: 'bold',
  },
  content: {
    padding: 16,
    paddingBottom: 80,
  },
  hero: {
    backgroundColor: '#0abaef',
    padding: 24,
    borderRadius: 10,
    marginBottom: 16,
    alignItems: 'center',
  },
  heroText: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
    color: '#333',
  },
  input: {
    height: 50,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
    fontSize: 16,
  },
  bookButton: {
    backgroundColor: '#096af1',
    padding: 14,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 8,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
  routeItem: {
    flexDirection: 'row',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  routeImage: {
    width: 80,
    height: 60,
    borderRadius: 6,
    marginRight: 12,
  },
  routeInfo: {
    flex: 1,
    justifyContent: 'center',
  },
  routeTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  routeDetail: {
    fontSize: 14,
    color: '#666',
  },
  sectionHeader: {
    fontSize: 16,
    fontWeight: 'bold',
    backgroundColor: '#f5f5f5',
    padding: 8,
  },
  switchContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#096af1',
    padding: 12,
    alignItems: 'center',
  },
  footerText: {
    color: 'white',
    fontSize: 14,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 20,
    width: '80%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 12,
    color: '#096af1',
    textAlign: 'center',
  },
  modalText: {
    fontSize: 16,
    marginBottom: 20,
    textAlign: 'center',
  },
  modalButton: {
    backgroundColor: '#096af1',
    padding: 12,
    borderRadius: 6,
    alignItems: 'center',
  },
  modalButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default TripGoApp;
